package dhbw.trasima.trasima_bis_5;

public interface IPositionPublisher {

    void publishPosition(int id, double x, double y, double speed);

}
